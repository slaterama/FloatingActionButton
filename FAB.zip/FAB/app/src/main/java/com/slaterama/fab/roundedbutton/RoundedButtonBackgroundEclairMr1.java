package com.slaterama.fab.roundedbutton;

import android.content.res.ColorStateList;
import android.graphics.drawable.StateListDrawable;

import com.slaterama.fab.LogEx;

import java.util.Arrays;

public class RoundedButtonBackgroundEclairMr1 extends StateListDrawable
		implements RoundedButtonBackgroundImpl {
	public RoundedButtonBackgroundEclairMr1(ColorStateList color) {
		super();
	}

	@Override
	public float getPadding() {
		return 0;
	}

	@Override
	public void setPadding(float padding, boolean insetForPadding, boolean insetForRadius) {

	}

	@Override
	public float getRadius() {
		return 0;
	}

	@Override
	public void setRadius(float radius) {

	}

	@Override
	public int[] getState() {
		int[] state = super.getState();
		LogEx.d(String.format("state=%s", Arrays.toString(state)));
		return state;
	}
}
