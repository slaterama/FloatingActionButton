package com.slaterama.fab.roundedbutton;

import android.graphics.drawable.Drawable;

public interface RoundedButtonDelegate {
	void setBackgroundDrawable(Drawable drawable);

	Drawable getBackground();

	boolean getUseCompatPadding();

	boolean getPreventCornerOverlap();

	float getRadius();

	void setShadowPadding(int left, int top, int right, int bottom);
}
