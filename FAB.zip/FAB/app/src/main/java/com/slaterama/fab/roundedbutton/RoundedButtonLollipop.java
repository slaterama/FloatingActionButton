package com.slaterama.fab.roundedbutton;

import android.content.Context;

public class RoundedButtonLollipop extends RoundedButtonImpl {
	@Override
	public void initStatic() {

	}

	@Override
	public void initialize(RoundedButtonDelegate button, Context context, int backgroundColor, int pressedColor, float radius, float elevation, float maxElevation) {

	}

	@Override
	public void setElevation(RoundedButtonDelegate button, float elevation) {

	}

	@Override
	public float getElevation(RoundedButtonDelegate button) {
		return 0;
	}

	@Override
	public void setMaxElevation(RoundedButtonDelegate button, float maxElevation) {

	}

	@Override
	public float getMaxElevation(RoundedButtonDelegate button) {
		return 0;
	}

	@Override
	public float getMinWidth(RoundedButtonDelegate button) {
		return 0;
	}

	@Override
	public float getMinHeight(RoundedButtonDelegate button) {
		return 0;
	}

	@Override
	public void setRadius(RoundedButtonDelegate button, float radius) {

	}

	@Override
	public float getRadius(RoundedButtonDelegate button) {
		return 0;
	}

	@Override
	public void updatePadding(RoundedButtonDelegate button) {

	}

	@Override
	public void onCompatPaddingChanged(RoundedButtonDelegate button) {

	}

	@Override
	public void onPreventCornerOverlapChanged(RoundedButtonDelegate button) {

	}
}
