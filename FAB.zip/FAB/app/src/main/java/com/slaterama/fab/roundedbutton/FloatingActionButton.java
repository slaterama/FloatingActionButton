package com.slaterama.fab.roundedbutton;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;

public class FloatingActionButton extends RoundedImageButton {

	public FloatingActionButton(Context context) {
		super(context);
	}

	public FloatingActionButton(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public FloatingActionButton(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
	}

	@TargetApi(Build.VERSION_CODES.LOLLIPOP)
	public FloatingActionButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		super(context, attrs, defStyleAttr, defStyleRes);
	}
}
