package com.slaterama.fab.roundedbutton;

import android.annotation.TargetApi;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.content.Context;
import android.graphics.Canvas;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageButton;

public class RoundedImageButton extends ImageButton {

	private static final RoundedButtonImpl IMPL;

	static {
		if (Build.VERSION.SDK_INT >= 21) {
			IMPL = new RoundedButtonLollipop();
		} else if (Build.VERSION.SDK_INT >= 17) {
			IMPL = new RoundedButtonJellybeanMr1();
		} else {
			IMPL = new RoundedButtonEclairMr1();
		}
		IMPL.initStatic();
	}

	public RoundedImageButton(Context context) {
		this(context, null);
	}

	public RoundedImageButton(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public RoundedImageButton(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initialize(context, attrs, defStyleAttr);
	}

	@TargetApi(Build.VERSION_CODES.LOLLIPOP)
	public RoundedImageButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		super(context, attrs, defStyleAttr, defStyleRes);
		initialize(context, attrs, defStyleAttr);
	}

	private void initialize(Context context, AttributeSet attrs, int defStyleAttr) {

	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		Rect measuredDimension = IMPL.getMeasuredDimension(widthMeasureSpec, heightMeasureSpec);
		setMeasuredDimension(measuredDimension.width(), measuredDimension.height());
	}

	@Override
	protected void onDraw(@NonNull Canvas canvas) {
		super.onDraw(canvas);
	}
}
