package com.slaterama.fab.roundedbutton;

import android.content.Context;
import android.graphics.Rect;

public abstract class RoundedButtonImpl {
	abstract void initStatic();

	abstract void initialize(RoundedButtonDelegate button, Context context,
					int backgroundColor, int pressedColor,
					float radius, float elevation, float maxElevation);

	Rect getMeasuredDimension(int widthMeasureSpec, int heightMeasureSpec) {
		return new Rect();
	}

	abstract void setElevation(RoundedButtonDelegate button, float elevation);

	abstract float getElevation(RoundedButtonDelegate button);

	abstract void setMaxElevation(RoundedButtonDelegate button, float maxElevation);

	abstract float getMaxElevation(RoundedButtonDelegate button);

	abstract float getMinWidth(RoundedButtonDelegate button);

	abstract float getMinHeight(RoundedButtonDelegate button);

	abstract void setRadius(RoundedButtonDelegate button, float radius);

	abstract float getRadius(RoundedButtonDelegate button);

	abstract void updatePadding(RoundedButtonDelegate button);

	abstract void onCompatPaddingChanged(RoundedButtonDelegate button);

	abstract void onPreventCornerOverlapChanged(RoundedButtonDelegate button);
}
