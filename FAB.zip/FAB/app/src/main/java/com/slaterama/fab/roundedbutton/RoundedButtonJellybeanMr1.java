package com.slaterama.fab.roundedbutton;

public class RoundedButtonJellybeanMr1 extends RoundedButtonEclairMr1 {

}
