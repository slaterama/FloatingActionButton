package com.slaterama.fab.roundedbutton;

public interface RoundedButtonBackgroundImpl {
	public float getPadding();

	public void setPadding(float padding, boolean insetForPadding, boolean insetForRadius);

	public float getRadius();

	public void setRadius(float radius);
}
